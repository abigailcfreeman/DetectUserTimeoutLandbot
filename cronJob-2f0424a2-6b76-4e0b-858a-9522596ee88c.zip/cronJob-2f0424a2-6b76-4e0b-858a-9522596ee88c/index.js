const axios = require('axios');

let customerID;

exports.handler = (event, context, callback) => {
  console.log(event);
let obj = JSON.parse(event.body);
customerID = obj.CustomerID.toString();
console.log(customerID);
console.log(obj);
};

const myTimeout = setTimeout(test, 60000);
function test(){
  console.log('test');
  var config = {
  method: 'get',
  url: 'https://api.airtable.com/v0/****your-table-id-here***/Table%201/?filterByFormula=({CustomerID}=' + customerID + ')',
  headers: { 
    'Authorization': 'Bearer **Your Airtable token here**', 
    'Content-Type': 'application/json', 
    'Cookie': 'brw=brwxut7TiG1AZEE2H'
  }
};

axios(config)
.then(function (response) {
    console.log(response.data.records[0].fields.Completed);
    if(response.data.records[0].fields.Completed == "True"){
    }
    else{
      console.log('not yet');
      reminder(customerID);
    }
  console.log(JSON.stringify(response.data));

})

function reminder(customerID){

  var data = '{\n"message": "hello why didnt you complete the bot"\n\n}';

    var config = {
      method: 'post',
      url: 'https://api.landbot.io/v1/customers/' + customerID + '/send_text/',
      headers: { 
        'Authorization': 'Token **Your Landbot Token**', 
        'Content-Type': 'text/plain'
      },
      data : data
    };
    
    axios(config)
    .then(function (response) {
      console.log(JSON.stringify(response.data));
    })
    .catch(function (error) {
      console.log(error);
    });
}
}
// });